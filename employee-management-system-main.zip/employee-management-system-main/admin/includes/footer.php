<footer class="admin-footer">
    <p>© <?php echo Date('Y'); ?> - Employee Management System. Developed By: Binod Raj Dhami</p>
</footer>
</div>
</body>

</html>