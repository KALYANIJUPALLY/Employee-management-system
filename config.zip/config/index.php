<?php
	$connect = new mysqli("localhost", "root", "", "db_employeemanagement");
?>